package com.fis.bankapplication.service;

import com.fis.bankapplication.model.Transaction;

import java.util.Date;
import java.util.List;

public interface TransactionService {
	
	// Method to add a new transaction
	public String addTransaction(Transaction transaction);
    
	// Method to update an existing transaction
	public String updateTransaction(Transaction transaction);
    
	// Method to delete a transaction by its ID
	public String deleteTransaction(long transactionId);
    
	// Method to get a transaction by its ID
	public Transaction getTransactionById(long transactionId);
    
	// Method to retrieve all transactions
	public List<Transaction> getAllTransactions();
	
	// Method to get account statements within a date range
	public List<Transaction> getAccountStatementsByDateRange(long accountId,Date startDate,Date endDate);
	
//	public List<Transaction> getLastTwoTransactions(long accountId);
    
	// Method to get all transactions for a specific account
	public List<Transaction> getTransactionsForAccount(long accountId);
}