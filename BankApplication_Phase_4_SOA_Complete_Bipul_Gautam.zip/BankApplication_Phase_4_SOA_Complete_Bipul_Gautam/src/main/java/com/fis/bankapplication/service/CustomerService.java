package com.fis.bankapplication.service;

import com.fis.bankapplication.exceptions.CustomerNotFoundException;
import com.fis.bankapplication.model.Customer;

import java.util.List;

public interface CustomerService {
	
	// Method to add a customer
    public String addCustomer(Customer customer);

    // Method to update a customer
    public String updateCustomer(Customer customer);

    // Method to delete a customer by their ID
    public String deleteCustomer(long customerId);

    // Method to get a customer by their ID
    public Customer getCustomer(long customerId) throws CustomerNotFoundException;

    // Method to retrieve all customers
    public List<Customer> getAllCustomers();
}