package com.fis.bankapplication;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.*;

import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.fis.bankapplication.exceptions.TransactionNotFoundException;
import com.fis.bankapplication.model.Account;
import com.fis.bankapplication.model.Customer;
import com.fis.bankapplication.model.Transaction;
import com.fis.bankapplication.repository.TransactionRepo;
import com.fis.bankapplication.service.TransactionServiceImpl;

public class TransactionTestsMockito {

    @Mock
    private TransactionRepo transactionRepo;

    @InjectMocks
    private TransactionServiceImpl transactionService;

    @BeforeEach
    public void init() {
        MockitoAnnotations.initMocks(this);
    }
    
    @Test
    public void testAddTransaction() {
        Customer customer = new Customer(1, "Bipul", "9876543210", "x@gmail.com", "333344445555", new Date(), "Pune", "Patna", "SE1");
        Account account = new Account(1, customer, "Savings", "Aundh", new Date(), "bipul123", 1000.0);

        Transaction transaction = new Transaction(1, account, account, 500.0, new Date(), "Deposit");

        when(transactionRepo.save(transaction)).thenReturn(transaction);

        String result = transactionService.addTransaction(transaction);

        assertEquals("Transaction added Successfully", result);
        verify(transactionRepo, times(1)).save(transaction);
    }

    @Test
    public void testUpdateTransaction() {
        Customer customer = new Customer(1, "Bipul", "9876543210", "x@gmail.com", "333344445555", new Date(), "Pune", "Patna", "SE1");
        Account account = new Account(1, customer, "Savings", "Aundh", new Date(), "bipul123", 1000.0);

        Transaction transaction = new Transaction(2, account, account, 500.0, new Date(), "Deposit");

        when(transactionRepo.save(transaction)).thenReturn(transaction);

        String result = transactionService.updateTransaction(transaction);

        assertEquals("Transaction updated Successfully", result);
        verify(transactionRepo, times(1)).save(transaction);
    }

    @Test
    public void testDeleteTransaction() {
        Transaction transaction = new Transaction(3, null, null, 500.0, new Date(), "Wrong Transfer");

        when(transactionRepo.findById(3L)).thenReturn(Optional.of(transaction));

        String result = transactionService.deleteTransaction(3L);

        assertEquals("Transaction deleted Successfully", result);
    }

    @Test
    public void testGetTransactionById() throws TransactionNotFoundException {
        Customer customer = new Customer(1, "Bipul", "9876543210", "x@gmail.com", "333344445555", new Date(), "Pune", "Patna", "SE1");
        Account account = new Account(1, customer, "Savings", "Aundh", new Date(), "bipul123", 1000.0);

        Transaction expectedTransaction = new Transaction(1, account, account, 2500, new Date(), "Deposit");

        when(transactionRepo.findById(1L)).thenReturn(Optional.of(expectedTransaction));

        Transaction actualTransaction = transactionService.getTransactionById(1L);

        assertNotNull(actualTransaction);
        assertEquals(expectedTransaction.getId(), actualTransaction.getId());
    }

    @Test
    public void testGetAllTransactions() {
        Customer customer = new Customer(1, "Bipul", "9876543210", "x@gmail.com", "333344445555", new Date(), "Pune", "Patna", "SE1");
        Account account = new Account(1, customer, "Savings", "Aundh", new Date(), "bipul123", 1000.0);

        Transaction transaction1 = new Transaction(1, account, account, 500, new Date(), "Deposit");
        Transaction transaction2 = new Transaction(2, account, account, 500, new Date(), "Withdraw");

        List<Transaction> transactions = List.of(transaction1, transaction2);

        when(transactionRepo.findAll()).thenReturn(transactions);

        List<Transaction> actualTransactions = transactionService.getAllTransactions();

        assertEquals(2, actualTransactions.size());
    }
}