package com.fis.bankapplication;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.times;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.fis.bankapplication.exceptions.CustomerNotFoundException;
import com.fis.bankapplication.model.Customer;
import com.fis.bankapplication.repository.CustomerRepo;
import com.fis.bankapplication.service.CustomerServiceImpl;

public class CustomerTestsMockito {

    @Mock
    private CustomerRepo customerRepo;

    @InjectMocks
    private CustomerServiceImpl customerService;

    @BeforeEach
    public void init() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testAddCustomer() {
        Customer customer = new Customer();
        when(customerRepo.save(customer)).thenReturn(customer);

        String result = customerService.addCustomer(customer);

        assertEquals("Customer added Successfully", result);
        verify(customerRepo, times(1)).save(customer);
    }

    @Test
    public void testUpdateCustomer() {
        Customer customer = new Customer();
        when(customerRepo.save(customer)).thenReturn(customer);

        String result = customerService.updateCustomer(customer);

        assertEquals("Customer updated Successfully", result);
        verify(customerRepo, times(1)).save(customer);
    }

    @Test
    public void testDeleteCustomer() throws CustomerNotFoundException {
        long customerId = 1L;
        Customer customer = new Customer();
        when(customerRepo.findById(customerId)).thenReturn(Optional.of(customer));

        String result = customerService.deleteCustomer(customerId);

        assertEquals("Customer Deleted Successfully", result);
        verify(customerRepo, times(1)).delete(customer);
    }

    @Test
    public void testGetCustomer() {
        long customerId = 1L;
        Customer customer = new Customer();
        when(customerRepo.findById(customerId)).thenReturn(Optional.of(customer));

        try {
            Customer retrievedCustomer = customerService.getCustomer(customerId);
            assertEquals(customer, retrievedCustomer);
        } catch (CustomerNotFoundException e) {
            System.out.println("Exception occured");
        }
    }

    @Test
    public void testGetAllCustomers() {
        List<Customer> customers = new ArrayList<>();
        when(customerRepo.findAll()).thenReturn(customers);

        List<Customer> retrievedCustomers = customerService.getAllCustomers();

        assertEquals(customers, retrievedCustomers);
    }
}