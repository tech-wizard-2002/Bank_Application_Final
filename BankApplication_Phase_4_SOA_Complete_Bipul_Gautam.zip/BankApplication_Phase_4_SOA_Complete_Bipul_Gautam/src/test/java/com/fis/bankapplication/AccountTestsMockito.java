package com.fis.bankapplication;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.fail;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.*;
import static org.mockito.Mockito.*;

import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import com.fis.bankapplication.exceptions.AccountNotFoundException;
import com.fis.bankapplication.model.Account;
import com.fis.bankapplication.model.Customer;
import com.fis.bankapplication.repository.AccountRepo;
import com.fis.bankapplication.service.AccountServiceImpl;
import com.fis.bankapplication.service.TransactionService;

public class AccountTestsMockito {

    @Mock
    private AccountRepo accountRepo;

    @Mock
    private TransactionService transactionService;

    @InjectMocks
    private AccountServiceImpl accountService;

    @BeforeEach
    public void setup() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testAddAccount() {
        Account account = new Account();

        when(accountRepo.save(account)).thenReturn(account);

        String result = accountService.addAccount(account);

        assertEquals("Account added Successfully", result);
        verify(accountRepo, times(1)).save(account);
    }

    @Test
    public void testUpdateAccount() {
        Account account = new Account();
        when(accountRepo.save(account)).thenReturn(account);

        String result = accountService.updateAccount(account);

        assertEquals("Account updated Successfully", result);
        verify(accountRepo, times(1)).save(account);
    }

    @Test
    public void testDeleteAccount() {
        long accountId = 1;

        Account account = new Account();
        when(accountRepo.findById(accountId)).thenReturn(Optional.of(account));

        String result = accountService.deleteAccount(accountId);

        assertEquals("Account Deleted Successfully", result);
        verify(accountRepo, times(1)).delete(account);
    }

    @Test
    public void testGetAccount() {
        long accountId = 1;

        Account account = new Account();
        when(accountRepo.findById(accountId)).thenReturn(Optional.of(account));

        try {
            Account returnedAccount = accountService.getAccount(accountId);
            assertNotNull(returnedAccount);
            assertEquals(account, returnedAccount);
        } catch (AccountNotFoundException e) {
            fail("Exception should not be thrown");
        }
    }

    @Test
    public void testDeposit() {
        Account account = new Account(); 
        double amount = 500.0;

        when(accountRepo.findById(anyLong())).thenReturn(Optional.of(account));
        doNothing().when(accountRepo).deposit(anyLong(), anyDouble());

        String result = accountService.deposit(anyLong(), amount);

        assertEquals("Deposit of " + amount + " successful. New balance: " + (account.getBalance() + amount), result);
        verify(accountRepo, times(1)).deposit(anyLong(), anyDouble());
    }

    

    @Test
    public void testWithdraw() {
        Account account = new Account(); 
        double amount = 200.0; 

        when(accountRepo.findById(anyLong())).thenReturn(Optional.of(account));
        doNothing().when(accountRepo).withdraw(anyLong(), anyDouble());

        String result = accountService.withdraw(anyLong(), amount);

        assertEquals("Withdraw of " + amount + " successful. New balance: " + (account.getBalance() - amount), result);
        verify(accountRepo, times(1)).withdraw(anyLong(), anyDouble());
    }

    @Test
    public void testFundTransfer() {
        Account fromAccount = new Account(); 
        Account toAccount = new Account(); 
        double amount = 300.0; 

        when(accountRepo.findById(fromAccount.getId())).thenReturn(Optional.of(fromAccount));
        when(accountRepo.findById(toAccount.getId())).thenReturn(Optional.of(toAccount));
        doNothing().when(accountRepo).fundTransferFrom(anyLong(), anyDouble());
        doNothing().when(accountRepo).fundTransferTo(anyLong(), anyDouble());

        String result = accountService.fundTransfer(fromAccount.getId(), toAccount.getId(), amount, "Transfer");

        double newBalanceFrom = fromAccount.getBalance() - amount;
        double newBalanceTo = toAccount.getBalance() + amount;

        assertEquals("Fund transfer of " + amount + " successful. New balance for sender: " + newBalanceFrom +
                ", new balance for receiver: " + newBalanceTo, result);
        verify(accountRepo, times(1)).fundTransferFrom(anyLong(), anyDouble());
        verify(accountRepo, times(1)).fundTransferTo(anyLong(), anyDouble());
    }

    @Test
    public void testGetAccountsByCustomerId() {
        long customerId = 1; 

        List<Account> accounts = Arrays.asList(new Account(), new Account()); 
        when(accountRepo.findByCustomer_Id(customerId)).thenReturn(accounts);

        List<Account> returnedAccounts = accountService.getAccountsByCustomerId(customerId);

        assertNotNull(returnedAccounts);
        assertEquals(accounts.size(), returnedAccounts.size());
        assertEquals(accounts, returnedAccounts);
    }

    @Test
    public void testGetTotalBalanceByCustomerId() {
        long customerId = 1; 
        double totalBalance = 2500.0; 

        when(accountRepo.sumBalanceByCustomerId(customerId)).thenReturn(totalBalance);

        double returnedTotalBalance = accountService.getTotalBalanceByCustomerId(customerId);

        assertEquals(totalBalance, returnedTotalBalance);
    }
}