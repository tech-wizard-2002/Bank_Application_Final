package com.auth.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.auth.Exceptions.NoSuchElementException;
import com.auth.Exceptions.UserExistsException;
import com.auth.dao.ApplicationUserDao;
import com.auth.models.ApplicationUser;

@Service
public class ApplicationUserService {

	@Autowired
	private ApplicationUserDao dao;

	public ApplicationUser isValid(String username, String password) {
		System.out.println(username + "In service");
		ApplicationUser user = dao.findByUsername(username);
		if (user == null) {
			throw new NoSuchElementException("No such User");

		} else {
			if (password.equals(user.getPassword())) {
				return user;
			} else {
				throw new NoSuchElementException("Invalid Password");
			}
		}
	}

	public void registerUser(ApplicationUser user) {
		ApplicationUser existingUser = dao.findByUsername(user.getUsername());
		if (existingUser != null) {
			throw new UserExistsException("Username already exists");
		}
		dao.save(user);
	}

	public boolean existsByUsername(String username) {
		ApplicationUser existingUser = dao.findByUsername(username);
		return existingUser != null;
	}
}
