package com.bankclient.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.Min;
import javax.validation.constraints.NotBlank;

@Entity
@Table(name = "accounts_info")
public class Account {

	@Id
	@GeneratedValue
	private long accNumber;
	private double accBalance;
	@NotBlank(message = "Account Branch must not be null ")
	private String accBranch;
	private String accOpenDate;
	@NotBlank(message = "Account type must not be null ")
	private String accType;

	public Account() {
		super();
	}

	
	
	public Account(
			@Min(value = 500, message = "Account Number Cannot be less than 500") long accNumber,
			double accBalance, @NotBlank(message = "Account Branch must not be null ") String accBranch,
			@NotBlank(message = "Account type must not be null ") String accType) {
		super();
		this.accNumber = accNumber;
		this.accBalance = accBalance;
		this.accBranch = accBranch;
		this.accType = accType;
	}



	public Account(long accNumber, double accBalance, String accBranch, String accOpenDate, String accType) {
		super();
		this.accNumber = accNumber;
		this.accBalance = accBalance;
		this.accBranch = accBranch;
		this.accOpenDate = accOpenDate;
		this.accType = accType;
	}

	public long getAccNumber() {
		return accNumber;
	}

	public void setAccNumber(long accNumber) {
		this.accNumber = accNumber;
	}

	public double getAccBalance() {
		return accBalance;
	}

	public void setAccBalance(double accBalance) {
		this.accBalance = accBalance;
	}

	public String getAccBranch() {
		return accBranch;
	}

	public void setAccBranch(String accBranch) {
		this.accBranch = accBranch;
	}

	public String getAccOpenDate() {
		return accOpenDate;
	}

	public void setAccOpenDate(String accOpenDate) {
		this.accOpenDate = accOpenDate;
	}

	public String getAccType() {
		return accType;
	}

	public void setAccType(String accType) {
		this.accType = accType;
	}

	@Override
	public String toString() {
		return String.format("Account [accNumber=%s, accBalance=%s, accBranch=%s, accOpenDate=%s, accType=%s]",
				accNumber, accBalance, accBranch, accOpenDate, accType);
	}

}
